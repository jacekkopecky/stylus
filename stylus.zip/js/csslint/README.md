## css-lint - modified from v0.10.0 (2013-08-15)

This version has been **heavily** modified since [it was originally added](https://github.com/openstyles/stylus/commit/b4173d68f6312300ab761f5454d7a8fb230d2bce#diff-4392791c2f6559cb1de01b0e1f3e1c08) in Stylish v1.3.0. It should be considered a fork of the [original](https://github.com/CSSLint/csslint).
